package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.example.model.Customer;

@Configuration
@ComponentScan(basePackages="com.example.model")
public class AppConfig {
	@Bean("customerargs") //context.getBean("customerargs",Long.valueof(15),"JJ");
	@Scope("propertype")
	public Customer createCustomerargs(Long id, String name) {
		return new Customer(id,name); //IOC container to create
	}
	@Bean("customer") //context.getBean("customer");
	@Scope("propertype")
	public Customer createCustomerargs() {
		return new Customer();
	}

}
