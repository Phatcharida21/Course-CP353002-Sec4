package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab502Sec4SendvaluesApplicationTests {

	@Test
	void contextLoads() {
	}

}
